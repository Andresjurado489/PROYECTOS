import libreria
import os

# Funciones

def buscarEnNomina(lista, mes, codigoEmpleado):
    posicion = -1
    for indice, registro in enumerate(lista):   #recorre toda la lista y extrae registro a registro con su indice
        #print(indice, " -- ", fila)  0.placa 1.marca 2.color......
        if str(registro[1]).upper() == codigoEmpleado and str(registro[0]).upper() == str(mes).upper():
            return indice
    return posicion


def filtrarEmpleadosActivos(empleados):
    sublista = []
    activo = 'A'
    for empleado in empleados:
        if empleado[7].upper() == activo:
            sublista.append(empleado)
    return sublista
        

def generarNominaMes ( empleados ):
    libreria.limpiarPantalla()
    print("*** INSERTAR NOVEDADES ***")
    print("*" * 30)
    mes             = libreria.leerDiccionario(diccionarioMeses, "Mes a pagar: ")
    empleadosActivos = filtrarEmpleadosActivos(empleados)
    #codigoEmpleado, posicionEmpleado  = libreria.leerCodigoValidado(empleados, "Código Empleado: ")
    #posicionEmpleado = libreria.buscar(empleados, codigoEmpleado)
    for empleado in empleadosActivos:
        codigoEmpleado  = empleado[0]
        diasTrabajados  = 30         
        salarioBasico   = empleado[8]
        pension         = salarioBasico * PORCENTAJE_PENSION
        salud           = salarioBasico * PORCENTAJE_SALUD
        auxTransporte   = (AUX_TRANSPORTE / 30) * diasTrabajados
        if salarioBasico > 2 * SALARIO_MINIMO:
            auxTransporte = 0
        salarioNeto     = salarioBasico + auxTransporte - pension - salud
        estado = 'N'
        
        nomina = [mes, codigoEmpleado, diasTrabajados, salarioBasico, pension, salud, auxTransporte, salarioNeto, estado]
        nominas.append(nomina)
    return nominas


def actualizarNovedad(encabezado, nomina):
    while True:
        libreria.mostrar(encabezado, nomina)
        print("*** ACTUALIZAR NOVEDADES ***")
        print("*" * 30)
      
        diasTrabajados  = libreria.leerEntero( "Días Trabajados: ", 1, 30 )
        nomina[2]       = diasTrabajados          
        salarioBasico   = nomina[3]
        pension         = salarioBasico * PORCENTAJE_PENSION
        salud           = salarioBasico * PORCENTAJE_SALUD
        auxTransporte   = (AUX_TRANSPORTE / 30) * diasTrabajados
        if salarioBasico > 2 * SALARIO_MINIMO:
            auxTransporte = 0
        salarioNeto     = salarioBasico + auxTransporte - pension - salud
        estado = libreria.leerDiccionario(diccionarioEstados, "Estado: ")
        nomina = [nomina[0], nomina[1], nomina[2], nomina[3], pension, salud, auxTransporte, salarioNeto, estado]
        return nomina

def insertar ( empleados ):
    libreria.limpiarPantalla()
    print("*** INSERTAR NOVEDADES ***")
    print("*" * 30)
    mes             = libreria.leerDiccionario(diccionarioMeses, "Mes a pagar: ")
    codigoEmpleado, posicionEmpleado  = libreria.leerCodigoValidado(empleados, "Código Empleado: ")
    #posicionEmpleado = libreria.buscar(empleados, codigoEmpleado)
    empleado = empleados[posicionEmpleado]
    diasTrabajados  = libreria.leerEntero( "Días Trabajados: ", 1, 30 )          
    salarioBasico   = empleado[8]
    pension         = salarioBasico * PORCENTAJE_PENSION
    salud           = salarioBasico * PORCENTAJE_SALUD
    auxTransporte   = (AUX_TRANSPORTE / 30) * diasTrabajados
    if salarioBasico > 2 * SALARIO_MINIMO:
        auxTransporte = 0
    salarioNeto     = salarioBasico + auxTransporte - pension - salud
    estado = 'N'
    
    nomina = [mes, codigoEmpleado, diasTrabajados, salarioBasico, pension, salud, auxTransporte, salarioNeto, estado]
    return nomina

# Variables globales
PORCENTAJE_PENSION = 0.04
PORCENTAJE_SALUD = 0.04
AUX_TRANSPORTE = 200000
SALARIO_MINIMO = 1423500

diccionarioMeses = {
    '1': "Enero",
    '2': "Febrero",
    '3': "Marzo",
    '4': "Abril",
    '5': "Mayo",
    '6': "Junio",
    '7': "Julio",
    '8': "Agosto",
    '9': "Septiembre",
    '10': "Octubre",
    '11': "Noviembre",
    '12': "Diciembre"
}

diccionarioEstados = {
    'N': "No Pagado",
    'P': "Pagado"
}

# La PK va a ser mes y código
#                0          1               2                    3             4       5         6              7
encabezado = ["mes", "codigoEmpleado", "diasTrabajados", "salarioBasico", "pension", "salud", "auxTransporte", "salarioNeto", "estado"]

# Estructuras para el almacenamiento temporal RAM
nomina = []
nominas = []
empleado = []
empleados = []

# Almacenamiento Permanente de los datos, disco duro
rutaDirectorio = "datos/"
nombreArchivoNominas   = os.path.join(rutaDirectorio, 'nominas.dat')
nombreArchivoEmpleados   = os.path.join(rutaDirectorio, 'empleados.dat')
# Cargar la Información almacenada a las estructuras
empleados = libreria.cargar(empleados, nombreArchivoEmpleados)
nominas = libreria.cargar(nominas, nombreArchivoNominas)

while True:
    libreria.menuCrud("PAGO DE NOMINA")
    opcion = libreria.LeerCaracter("Ingrese la Opcion: ")
    match (opcion):
        case '1':
            #nomina = insertar(empleados)
            nominas = generarNominaMes ( empleados )
            #nominas.append(nomina)
            libreria.guardar(nominas, nombreArchivoNominas)
            libreria.mensajeEsperaSegundos("Insertada la Novedad", 1)
        case '2':
            libreria.listar(encabezado, nominas)
            libreria.mensajeEsperaEnter("<ENTER> para continuar")
            
        case '3':
            codigoEmpleado, posicionEmpleado = libreria.leerCodigoValidado(empleados, "Código Empleado: ")
            mensaje = "No Encontrado"
            mes = libreria.leerDiccionario(diccionarioMeses, "Mes: ")
            posicion = buscarEnNomina(nominas, mes, codigoEmpleado)
            if posicion >= 0:
                libreria.mostrar(encabezado, nominas[posicion])
                libreria.guardar(nominas, nombreArchivoNominas)
    
                mensaje = "Consulta Finalizada"
            libreria.mensajeEsperaEnter("<ENTER> para Continuar..")
        case '4':
            codigoEmpleado, posicionEmpleado = libreria.leerCodigoValidado(empleados, "Código Empleado: ")
            mensaje = "No Encontrado"
            mes = libreria.leerDiccionario(diccionarioMeses, "Mes: ")
            posicion = buscarEnNomina(nominas, mes, codigoEmpleado)
            if posicion >= 0:
                nomina = actualizarNovedad(encabezado, nominas[posicion])
                nominas[posicion] = nomina
                libreria.guardar(nominas, nombreArchivoNominas)
    
                mensaje = "Novedad Actualizada"
            libreria.mensajeEsperaSegundos(mensaje, 1)
            
        case '6':
            libreria.mensajeEsperaSegundos("Saliendo del Programa", 1)
            break
        case _:
            libreria.mensajeEsperaSegundos("Opción no válida", 1)
        
        

        
        
